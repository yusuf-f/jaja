<div class="row">
	<div class="col-md-12">
        <div class="alert alert-primary" role="alert">
			Create By Yusuf Fadillah | &#169; 2021 All Rights Reserved
		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\tugas_laravel\resources\views/layouts/footer.blade.php ENDPATH**/ ?>